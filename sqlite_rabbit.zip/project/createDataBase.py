from sideFunc.table2_1 import countries1
from sideFunc.table2_3 import countries3
from sideFunc.Sqlite import *

dataBase = "C:\Users\שירן\PycharmProjects\sql\chinook.db"
countryData = """ CREATE TABLE IF NOT EXISTS countryData (
                                       id integer PRIMARY KEY,
                                       name text NOT NULL,
                                       date integer,
                                       numberOfBuying integer,
                                       listOfAlbums text,
                                       UNIQUE(name,date,numberOfBuying,listOfAlbums)
                                       
                                   ); """
countryData3 = """ CREATE TABLE IF NOT EXISTS countryData3 (
                                       id integer PRIMARY KEY,
                                       name text NOT NULL,
                                       date integer,
                                       numberOfsells integer,
                                       diskNames text,
                                       type text,
                                       UNIQUE(name,date,numberOfsells,diskNames,type)
                                   ); """


def createDataBase2_1(cursor, createObject): #todo
    """
    create a new table every time its run.
    :param cursor: the cursor object
    :param createObject: the createObject object
    :return:
    """
    cursor.execute(countryData)  # create the table.
    subjects = ("name", "date", "numberOfBuying", "listOfAlbums")
    for country in countries1 :
        project_id = createObject.addIntoTable(country, "countryData", subjects) # add the rows into the table.

def createDataBase2_3(cursor, createObject):#todo
    """
        create a new table every time its run.
        :param cursor: the cursor object
        :param createObject: the createObject object
        :return:
        """
    cursor.execute(countryData3)  # create the table.
    subjects = ("name","date","numberOfsells","diskNames","type")
    for country in countries3:
        project_id = createObject.addIntoTable(country, "countryData3", subjects)  # add the rows into the table.


def main():
    connectSqlite = logInSqlite()  # call  the sqlite class
    connectSqlite.setDataBase(dataBase)  # set the database
    connectSqlite.connect()  # connect to the database.
    connection = connectSqlite.getConnection()  # get the connection object.
    createObject = create()  # call the sqlite create class (sqlite tools).
    createObject.setCursor(connection)  # set a cursor as our command tool.
    cursor = createObject.getCursor()  # get the cursor object.
    #cursor.execute("DROP TABLE countryData")
    createDataBase2_1(cursor, createObject)  # update the database. (if the user changed the database)
    createDataBase2_3(cursor, createObject)  # create the 2_3 database
    connection.commit()
    find = createObject.selectAllTasks("SELECT * FROM countryData")

    print(find)

main()