
python fles:
main.py -> connect to the database and create the files.
server.py  -> active the server that get the messages from the client.
client.py -> active the client terminal. 
Rabbitmq.py -> has the connection class and the tools class . both of them create the rabbit objects.
Sqlite.py.py -> has the connection class and the tools class . both of them create the sqlite objects.
tools.py ->has funcs that can create directories , write to files , load files and more .
dataBase2_1.py -> has the database for that exercise . (its there for now so the user can change , for the practice , the table that we are using ).


need to install :
>pandas
> sqlite from the sqlite site ->http://www.sqlitetutorial.net/
> rabbitmq from the rabbitmq site ->http://www.rabbitmq.com/#getstarted

what to do :
1)download the packages.
2) put the sqlite files on c:\sqlite
3)create a path for c:\sqlite.
4) active the server.py file with pycharm , or cmd :
5)createDataBase.py every time you want to create\ or update ur database. (do it on the first time ).
6)active the client.py file with pycharm or cmd:
7) put the input that its asks from you:
example:
the location of the dataBase:C:\Users\שירן\PycharmProjects\sql\chinook.db
the country you want to get:israel
the date:2005

8) done! you will get a result file (if nothing went wrong) near to your main.py file.

*chinook.db is the database . be sure to create a right path to it . like: C:\Users\שירן\PycharmProjects\sql\chinook.db
