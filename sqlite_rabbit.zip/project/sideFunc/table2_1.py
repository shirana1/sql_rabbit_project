"""
the database (can be changed by the user.) for 2.1 and 2.2
it will be loaded to the database.
"""
countries1 = [('bulgaria', '1999', 60, '["hello", "new", "song"]'),
('israel', '2000', 70, '["life", "high", "road"]'),
('america', '2001', 80, '["flower", "ok", "good"]'),
('bulgaria', '2002', 90, '["jump", "over", "rainbow"]'),
('israel', '2003', 20, '["highroad", "forest", "eyal"]'),
('albania', '1990', 10, '["words", "bit", "love"]'),
('brazil', '1980', 70, '["death", "sleep", "now"]'),
('canada', '1970', 30, '["say", "to", "me"]'),
('egypt', '1960', 40, '["buff", "lol", "rock"]'),
('germany', '1950', 50, '["eve", "ryz", "ww"]'),
('haiti', '2019', 100, '["loop", "row", "while"]'),
('india', '2010', 110, '["song", "to", "me"]'),
('israel', '2005', 120, '["play", "with", "me"]'),
('israel', '2003', 130, '["country", "roads", "lol"]'),

                 ]