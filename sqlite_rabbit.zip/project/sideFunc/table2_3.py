"""
the database (can be changed by the user.) for 2.3
it will be loaded to the database.
"""
countries3 = [('bulgaria', '1999', 60, 'disk1', "ROCK"),
('israel', '2000', 70, 'disk2', "ROCK"),
('america', '2001', 80, 'disk3', "ROCK"),
('bulgaria', '2002', 90, 'disk4', "ROCK"),
('israel', '2003', 20, 'disk5', "ROCK"),
('albania', '1990', 10, 'disk6', "ROCK"),
('brazil', '1980', 70, 'disk7', "MAX"),
('canada', '1970', 30, 'disk8', "MAX"),
('egypt', '1960', 40, 'disk9', "ROCK"),
('germany', '1950', 50, 'disk10', "MAX"),
('haiti', '2019', 100, 'disk11', "ROCK"),
('india', '2010', 110, 'disk12', "NEW"),
('israel', '2005', 120, 'disk13', "ROCK"),
('israel', '2010', 130, 'disk14', "MAX"),
('israel', '2011', 140, 'disk15', "MAX"),

                 ]