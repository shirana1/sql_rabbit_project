from sideFunc.Sqlite import *
from sideFunc.tools import *
import xml.etree.cElementTree as etree
import os
import datetime
"""
Description = open a rabbit server server , get your information, go to the sqlite databse  and return the results to 
csv, json and xml files.
~please read 'README.txt' file before starting!~
"""

baseFolder = ""


def main(results):  # the main func
    now = datetime.datetime.now()
    timeFormat = now.strftime("%d_%m_%y-%H_%M_%S")
    location = createDirectory(baseFolder+"results")
    connectSqlite = logInSqlite()  # call  the sqlite class
    if os.path.isfile(results["location"]):  # check if you gave the right location and file.
        connectSqlite.setDataBase(results["location"])  # set the database
        connectSqlite.connect()  # connect to the database.
        connection = connectSqlite.getConnection()  # get the connection object.
        createObject = create()  # call the sqlite create class (sqlite tools).
        createObject.setCursor(connection)  # set a cursor as our command tool.
        cursor = createObject.getCursor()  # get the cursor object.


        #get the rows with the same country and date that the user gave us.
        sql = """SELECT * FROM countryData WHERE date = '{}' AND name = '{}';""".format(results["date"],results["country"])
        found = createObject.selectAllTasks(sql)

        if found:  # check if we found some results
            path = createDirectory("{}{}".format(location,timeFormat))
            subjects = (list(map(lambda x: x[0], cursor.description)))  # get the subjects of the database
            subjectsToPutIn = ["name", "numberOfBuying"]  # the subjects we need for the csv.
            writeToCSV(path=path, rows=found, subject=subjects, subjectsToPutIn=subjectsToPutIn)  # write to csv.
            subjectsToPutIn = ["name", "listOfAlbums"]  # the subjects we need for the json file.
            writeDictToFile(path + "result.json", rows=found, subject=subjects, subjectsToPutIn=subjectsToPutIn)  # write to json file.
            connection.commit()  # save the actions we did (if we did any).
            print(found)
            print ("done!")  # print if the program finished.


        else:  # if we didnt find a results print error and finish.
            print ("couldn't find a results for your search table: 2_1. please try again.")


        # get the higher seller from the chosen country (try israel , 2005 . )
        sql = """SELECT * FROM countryData3 WHERE date >= '{0}' AND name = '{1}' AND numberOfsells=(SELECT MAX(numberOfsells) FROM countryData3 WHERE name = '{1}' AND type = 'ROCK') ;""".format(
            results["date"], results["country"])
        found = createObject.selectAllTasks(sql)  # found
        find = createObject.selectAllTasks("SELECT * FROM countryData3")
        print (find)
        if found:
            path = createDirectory("{}{}".format(location, timeFormat))
            writeToXml(path+"result.xml",found)  # write to xml file.
            print (found)
        else:  # if we didnt find a results print error and finish.
            print("couldn't find a results for your search table: 2_3. please try again.")
        connectSqlite.disconnect()  # disconnect from the database.

    else:  # if the user didnt put the right path print error and finish.
        print ("invalid location! please try again...")
